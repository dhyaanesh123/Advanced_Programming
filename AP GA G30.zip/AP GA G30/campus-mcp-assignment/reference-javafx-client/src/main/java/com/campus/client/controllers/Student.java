package com.campus.client.controllers;

import com.campus.client.mcp.CampusMcpClient;
import com.campus.client.models.Booking;
import com.campus.client.models.BookingStatus;
import com.campus.client.rag.RagService;
import com.campus.client.services.AiTaskService;
import com.campus.client.services.AuthService;
import com.campus.client.services.BookingService;
import com.campus.client.services.ChatService;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public class Student {

    // Side-menu elements
    @FXML
    private Label facilities;

    @FXML
    private Label handbook;

    @FXML
    private Label home;

    @FXML
    private Label booking;

    @FXML
    private Label resource;

    @FXML
    private Label aiAssistant;

    // Main content container in Student Page.fxml.
    @FXML
    private StackPane contentArea;

    // Root container used by individual Student content pages.
    @FXML
    private AnchorPane contentArea2;

    @FXML
    private Label profileLabel;

    // Booking-page elements declared in Booking Page(Student).fxml.
    @FXML
    private VBox bookingListContainer;

    @FXML
    private Label recordCountLabel;

    private AuthService authService;
    private CampusMcpClient mcpClient;
    private RagService ragService;

    private Parent aiAssistantPage;
    private StudentAiAssistant aiAssistantController;

    private final AiTaskService aiTaskService = new AiTaskService();
    private final ChatService chatService = new ChatService();

    // Used by Booking page to retrieve and cancel the current student's bookings
    private final BookingService bookingService = new BookingService();

    public void setAuthService(AuthService authService) {
        this.authService = authService;

        if (profileLabel != null
                && authService != null
                && authService.getCurrentUser() != null) {

            profileLabel.setText(
                    authService.getCurrentUser().getFullName()
            );
        }
        if (contentArea != null) {
            onHomeClicked(null);
        }
    }

    public void setMcpClient(CampusMcpClient mcpClient) {
        this.mcpClient = mcpClient;
    }

    public void setRagService(RagService ragService) {
        this.ragService = ragService;
    }

    @FXML
    void onHomeClicked(MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Home Page(Student).fxml")
            );

            Parent fxml = loader.load();

            StudentHomePage controller = loader.getController();
            controller.setAuthService(this.authService);
            controller.setMcpClient(this.mcpClient);

            contentArea.getChildren().setAll(fxml);

        } catch (IOException exception) {
            exception.printStackTrace();
            System.out.println("Error: Could not load Home Page(Student).fxml. Check the file path!");
        }
    }

    @FXML
    void onResourceClicked(MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Resource Page(Student).fxml")
            );

            Parent root = loader.load();

            StudentResourcePage controller = loader.getController();

            controller.setAuthService(authService);
            controller.setMcpClient(this.mcpClient);

            contentArea.getChildren().setAll(root);

        } catch (IOException exception) {
            exception.printStackTrace();
            System.out.println("Error: Could not load Resource Page(Student).fxml. Check the file path!");
        }
    }

    @FXML
    void onBookingClicked(MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Booking Page(Student).fxml")
            );

            Parent fxml = loader.load();

            Student controller = loader.getController();

            controller.setMcpClient(this.mcpClient);
            controller.setAuthService(this.authService);
            controller.loadBookings();

            contentArea.getChildren().setAll(fxml);

        } catch (IOException exception) {
            exception.printStackTrace();
            System.out.println("Error: Could not load Booking Page(Student).fxml. Check the file path!");
        }
    }

    @FXML
    void onBookNowClicked(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/Resource Page(Student).fxml")
            );

            Parent resourceView = loader.load();

            StudentResourcePage controller = loader.getController();
            controller.setAuthService(this.authService);
            controller.setMcpClient(this.mcpClient);

            Button clickedButton = (Button) event.getSource();
            Scene currentScene = clickedButton.getScene();

            StackPane mainContentArea = (StackPane) currentScene.lookup("#contentArea");

            if (mainContentArea != null) {
                mainContentArea.getChildren().setAll(resourceView);
            } else {
                System.err.println("Error: Could not find the main content area (#contentArea).");
            }

        } catch (IOException exception) {
            exception.printStackTrace();
            System.out.println("Error: Could not load Resource Page(Student).fxml. Check the file path!");
        }
    }

    @FXML
    void onFacilitiesClicked(MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Facilities Page(Student).fxml"));

            Parent root = loader.load();

            StudentFacilityPage controller = loader.getController();
            controller.setAuthService(authService);
            controller.setMcpClient(this.mcpClient);

            contentArea.getChildren().setAll(root);

        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    @FXML
    void onHandbookClicked(MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Handbook Page(Student).fxml")
            );

            Parent root = loader.load();

            StudentHandbookPage controller = loader.getController();
            controller.setAuthService(authService);
            controller.setMcpClient(this.mcpClient);

            contentArea.getChildren().setAll(root);

        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    @FXML
    void onAiAssistantClicked(MouseEvent event) {
        try {
            if (aiAssistantPage == null) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/AI Assistant Page(Student).fxml"));

                aiAssistantPage = loader.load();
                aiAssistantController = loader.getController();

                aiAssistantController.setMcpClient(mcpClient);
                aiAssistantController.setRagService(ragService);
                aiAssistantController.setAuthService(authService);

                aiAssistantController.setChatService(chatService);
                /*
                 * ChatService is set before AiTaskService so previous
                 * conversation history is available to the AI request.
                 */
                aiAssistantController.setAiTaskService(aiTaskService);
            }

            contentArea.getChildren().setAll(aiAssistantPage);

        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    @FXML
    private void onLogOut() {
        if (aiAssistantController != null) {
            aiAssistantController.clearConversation();
        } else {
            chatService.clearConversation();
            aiTaskService.cancelCurrentTask();
        }

        if (authService != null) {
            authService.logout();
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/login.fxml"));

            Parent root = loader.load();

            Login login = loader.getController();
            login.setMcpClient(mcpClient);
            login.setRagService(ragService);

            javafx.stage.Stage stage = (javafx.stage.Stage) contentArea.getScene().getWindow();

            stage.setScene(new javafx.scene.Scene(root));
            stage.setMaximized(false);
            stage.show();

        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    // Displays past bookings from the previous seven days and upcoming bookings
    public void loadBookings() {
        if (bookingListContainer == null) {
            System.out.println("bookingListContainer is null");
            return;
        }
        bookingListContainer.getChildren().clear();
        bookingListContainer.setSpacing(10);

        if (authService == null || authService.getCurrentUser() == null) {
            showBookingMessage("No authenticated student was found.");
            return;
        }
        String studentId = authService.getCurrentUser().getId();

        // BookingService updates expired Confirmed bookings to Completed & filters out records older than seven days
        List<Booking> visibleBookings = bookingService.getVisibleStudentBookings(studentId);

        if (recordCountLabel != null) {
            recordCountLabel.setText(visibleBookings.size() + " RECORDS");
        }
        if (visibleBookings.isEmpty()) {
            showBookingMessage("No recent or upcoming bookings found.");
            return;
        }
        for (Booking booking : visibleBookings) {
            bookingListContainer.getChildren().add(buildBookingCard(booking));
        }
    }

    // Creates a booking card
    private HBox buildBookingCard(Booking booking) {
        HBox card = new HBox(15);

        card.setAlignment(Pos.CENTER_LEFT);

        card.setStyle("-fx-background-color: #202020;"
                        + "-fx-padding: 14;"
                        + "-fx-background-radius: 8;"
        );

        Label bookingLabel = new Label("Booking ID: " + booking.getBookingId()
                                        + "\nResource: " + booking.getResourceId()
                                        + "\nDate: " + booking.getBookingDate()
                                        + "\nTime: " + booking.getStartTime()
                                        + " - " + booking.getEndTime()
                                        + "\nStatus: " + booking.getStatus()
        );

        bookingLabel.setStyle("-fx-text-fill: white;"
                            + "-fx-font-size: 14px;"
        );

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button actionButton = new Button();

        // Only upcoming Confirmed bookings can be cancelled
        if (booking.getStatus() == BookingStatus.CONFIRMED
                && isUpcomingBooking(booking)) {

            actionButton.setText("Cancel Booking");
            actionButton.setDisable(false);

            actionButton.setStyle("-fx-background-color: #D32F2F;"
                                + "-fx-text-fill: white;"
                                + "-fx-font-weight: bold;"
                                + "-fx-cursor: hand;"
                                + "-fx-background-radius: 5;"
            );

            actionButton.setOnAction(
                    event -> handleCancelBooking(booking)
            );

        } else if (booking.getStatus() == BookingStatus.CANCELLED) {
            actionButton.setText("Cancelled");
            actionButton.setDisable(true);      // Button is disabled

            actionButton.setStyle("-fx-background-color: #555555;"
                                + "-fx-text-fill: #aaaaaa;"
            );

        } else if (booking.getStatus() == BookingStatus.COMPLETED) {
            actionButton.setText("Completed");
            actionButton.setDisable(true);      // Button is disabled

            actionButton.setStyle("-fx-background-color: #555555;"
                                + "-fx-text-fill: #aaaaaa;"
            );

        } else {

            // An ongoing booking is shown as in progress.
            actionButton.setText("In Progress");
            actionButton.setDisable(true);

            actionButton.setStyle("-fx-background-color: #555555;"
                                + "-fx-text-fill: #aaaaaa;"
            );
        }
        card.getChildren().addAll(bookingLabel, spacer, actionButton);
        return card;
    }

    // Returns true only when booking starts after current date & time
    private boolean isUpcomingBooking(Booking booking) {
        LocalDateTime bookingStart = LocalDateTime.of(booking.getBookingDate(), booking.getStartTime());
        return bookingStart.isAfter(LocalDateTime.now());
    }

    // Request confirmation, cancel selected booking, save new status * refreshes Booking page
    private void handleCancelBooking(Booking booking) {
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);

        confirmation.setTitle("Cancel Booking");

        confirmation.setHeaderText("Cancel booking " + booking.getBookingId() + "?");

        confirmation.setContentText("Resource: " + booking.getResourceId()
                                    + "\nDate: " + booking.getBookingDate()
                                    + "\nTime: " + booking.getStartTime()
                                    + " - " + booking.getEndTime()
        );

        Optional<ButtonType> result = confirmation.showAndWait();

        if (result.isEmpty() || result.get() != ButtonType.OK) {
            return;
        }

        boolean cancelled = bookingService.cancelBooking(booking.getBookingId());

        if (cancelled) {
            Alert success = new Alert(Alert.AlertType.INFORMATION);
            success.setHeaderText("Booking cancelled successfully.");
            success.setContentText("Booking " + booking.getBookingId() + " is now marked as CANCELLED.");
            success.showAndWait();
            loadBookings();

        } else {
            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setHeaderText("Booking could not be cancelled.");
            error.setContentText("The booking may already be cancelled, completed, or unavailable.");
            error.showAndWait();
        }
    }

    private void showBookingMessage(String message) {
        Label label = new Label(message);

        label.setStyle("-fx-text-fill: white;"
                        + "-fx-font-size: 14px;"
                        + "-fx-padding: 10;"
        );
        bookingListContainer.getChildren().add(label);
    }

}