package com.campus.client.services;

import com.campus.client.models.Booking;
import com.campus.client.models.BookingStatus;
import com.campus.client.repositories.BookingRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class BookingService {

    private final BookingRepository bookingRepository;              // Access stored booking records

    public BookingService() {                                       // Create repository when BookingService is created
        this.bookingRepository = new BookingRepository();
    }

    public List<Booking> getStudentBookings(String studentId) {     // Retrieved relevant booking to the Student ID
        return bookingRepository.findBookingsByStudentId(studentId);
    }

    public List<Booking> getVisibleStudentBookings(String studentId) {
        /*
        Display bookings in order of:
        1. Upcoming confirmed booking
        2. Completed or Cancelled booking
         */

        bookingRepository.updateCompletedBookings();
        // Changed expired confirmed bookings status to Completed before retrieval and list arrangement

        LocalDate today = LocalDate.now();

        LocalDate earliestVisibleDate = today.minusDays(7);
        // Only up to 7 days prior to current date

        LocalDateTime now = LocalDateTime.now();

        return bookingRepository.findBookingsByStudentId(studentId).stream()

                /*
                Retain all upcoming bookings.
                Only records within 7 days prior is kept
                 */
                .filter(booking ->
                                isUpcomingBooking(booking, now) || !booking.getBookingDate().isBefore(earliestVisibleDate)
                )

                /*
                Arrange in order of:
                1. Upcoming confirmed bookings
                2. Completed or Cancelled bookings
                 */
                .sorted(Comparator.comparingInt((Booking booking) ->
                                                getBookingGroup(booking, now)).thenComparingInt(
                                                        booking ->
                                                                getBookingIdNumber(booking.getBookingId()))
                )
                .collect(Collectors.toList());
    }

    //Identify if the booking is an upcoming confirmed booking
    private boolean isUpcomingBooking(Booking booking, LocalDateTime now) {
        LocalDateTime bookingStart = LocalDateTime.of(booking.getBookingDate(),
                                                        booking.getStartTime()
                );
        return booking.getStatus() == BookingStatus.CONFIRMED && bookingStart.isAfter(now);
    }

    // Booking display grouping
    private int getBookingGroup(Booking booking, LocalDateTime now) {
        return isUpcomingBooking(booking, now)
                ? 0     // Upcoming
                : 1;    // Completed / Cancelled
    }

    // Extract Booking ID number
    private int getBookingIdNumber(String bookingId) {
        if (bookingId == null || bookingId.isBlank()) {
            return Integer.MAX_VALUE;
        }

        try {
            String numericPart = bookingId.replaceAll("\\D+", "");
            // Remove non-numerical character

            // ID with no numerical section is placed at the end
            if (numericPart.isBlank()) {
                return Integer.MAX_VALUE;
            }

            return Integer.parseInt(numericPart);

        } catch (NumberFormatException exception) {
            // Invalid Booking ID is placed at the end
            return Integer.MAX_VALUE;
        }
    }

    // Cancel booking with passed Booking ID
    public boolean cancelBooking(String bookingId) {
        return bookingRepository.cancelBooking(bookingId);
    }

}