package com.campus.client.controllers;

import com.campus.client.mcp.CampusMcpClient;
import com.campus.client.models.Resource;
import com.campus.client.models.ResourceStatus;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.io.*;
import java.time.LocalDate;
import java.util.*;

public class AdminResourcePage {

    @FXML
    private VBox resourceListContainer;

    @FXML
    private TextField searchField;

    private CampusMcpClient mcpClient;

    private static final String BLOCKED_FILE = "data/blocked_resources.csv";

    private final List<Resource> resources = new ArrayList<>();

    private final Set<String> blockedIds = new HashSet<>();

    private final Set<String> mcpBookableIds = new HashSet<>();

    @FXML
    public void initialize() {
        loadBlockedIds();

        if (searchField != null) {
            searchField.textProperty().addListener(
                    (observable, oldValue, newValue) ->
                            refreshList()
            );
        }
        refreshList();
    }

    public void setMcpClient(CampusMcpClient mcpClient) {
        if (mcpClient == null) {
            showAlert("The Admin Resource page did not " + "receive the MCP client.");
            return;
        }
        this.mcpClient = mcpClient;

        loadBlockedIds();
        loadMcpBookableIds();
        loadResourcesFromMcp();
        refreshList();
    }

    // Retrieves all resource records from campus://facilities & convert them into a resource object
    private void loadResourcesFromMcp() {
        resources.clear();      // Prevent duplicated records

        try {
            String text = mcpClient.readResource("campus://facilities");

            // Indicates whether parser has reached Bookable Resources section
            boolean inTable = false;

            for (String line : text.split("\\R")) {
                String trimmed = line.trim();

                if (trimmed.equalsIgnoreCase("[Bookable Resources]")) {
                    inTable = true;
                    continue;
                }
                if (!inTable) {
                    continue;
                }
                if (trimmed.startsWith("[")) {
                    break;
                }
                if (trimmed.isBlank() || trimmed.toUpperCase(Locale.ROOT).startsWith("ROOM")) {
                    continue;
                }

                // Resource fields in MCP responses are separated using the "|" character
                String[] parts = trimmed.split("\\|");

                if (parts.length < 4) {
                    continue;
                }

                String id = parts[0].trim();
                String type = parts[1].trim();
                String building = parts[3].trim();
                String key = normaliseId(id);       // Prevent comparison failure

                // Resource is blocked if it exists in blocked_resources.csv
                ResourceStatus status = blockedIds.contains(key)
                                ? ResourceStatus.BLOCKED
                                : ResourceStatus.AVAILABLE;

                resources.add(new Resource(
                        id,
                        id,
                        friendlyBuilding(building),
                        status,
                        mcpBookableIds.contains(key),
                        type));
            }

        } catch (Exception exception) {
            showAlert("Could not read facilities: " + exception.getMessage());
            exception.printStackTrace();
        }
    }

    private void loadMcpBookableIds() {
        mcpBookableIds.clear();

        try {

            // Request availability for tomorrow to know which resource IDs are recognised by MCP
            String response = mcpClient.callTool("check_room_availability",
                            Map.of("date", LocalDate.now().plusDays(1).toString()));

            if (response == null
                    || response.isBlank()
                    || isErrorResponse(response)) {
                return;
            }

            for (String line : response.split("\\R")) {
                String trimmed = line.trim();

                if (trimmed.isBlank()
                        || !trimmed.contains("->")
                        || trimmed.toLowerCase(Locale.ROOT)
                        .startsWith("availability on")) {
                    continue;
                }

                String[] tokens = trimmed.split("\\s+");

                // First value in each availability row represents resource ID
                if (tokens.length > 0) {
                    mcpBookableIds.add(normaliseId(tokens[0]));
                }
            }

        } catch (Exception exception) {
            System.err.println("Could not load MCP-bookable IDs: " + exception.getMessage());
        }
    }

    private void refreshList() {
        if (resourceListContainer == null) {
            return;
        }

        resourceListContainer.getChildren().clear();
        resourceListContainer.setSpacing(10);

        String keyword = searchField == null || searchField.getText() == null
                        ? ""
                        : searchField.getText().trim().toLowerCase(Locale.ROOT);

        for (Resource resource : resources) {
            String searchable = (
                    resource.getName() + " " +
                    resource.getLocation() + " " +
                    resource.getType()).toLowerCase(Locale.ROOT);

            if (searchable.contains(keyword)) {
                resourceListContainer.getChildren().add(buildCard(resource));
            }
        }
    }

    private HBox buildCard(Resource resource) {
        HBox card = new HBox(15);

        card.getStyleClass().add("resource-item");
        card.setAlignment(Pos.CENTER_LEFT);

        String type = resource.getType().toLowerCase(Locale.ROOT);

        String iconText = "📍";

        if (type.contains("room")) {
            iconText = "👥";
        } else if (type.contains("pod")) {
            iconText = "📖";
        } else if (type.contains("lab")) {
            iconText = "🖥️";
        } else if (type.contains("court") || type.contains("sport")) {
            iconText = "⚽";
        }

        Label iconLabel = new Label(iconText);
        iconLabel.setStyle("-fx-font-size: 24;");

        VBox iconBox = new VBox(iconLabel);
        iconBox.getStyleClass().add("resource-icon-box");
        iconBox.setAlignment(Pos.CENTER);
        iconBox.setPrefSize(45, 45);

        Label nameLabel = new Label(resource.getName());
        nameLabel.getStyleClass().add("resource-title");

        Label locationLabel = new Label(resource.getLocation());
        locationLabel.getStyleClass().add("resource-location");

        VBox textDetails = new VBox(3, nameLabel, locationLabel);

        Region spacer = new Region();

        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label statusLabel = new Label();
        Button toggleButton = new Button();

        toggleButton.setStyle(
                "-fx-background-color: #2196F3;"
                        + "-fx-text-fill: white;"
                        + "-fx-background-radius: 5;"
                        + "-fx-cursor: hand;"
        );

        if (resource.getStatus() == ResourceStatus.BLOCKED) {

            statusLabel.setText("BLOCKED");
            statusLabel.setStyle(
                    "-fx-text-fill: #F44336;"
                            + "-fx-font-size: 12;"
                            + "-fx-font-weight: bold;"
            );

            toggleButton.setText("Unblock");
            toggleButton.setOnAction(event -> toggleBlock(
                    resource,
                    ResourceStatus.AVAILABLE
                    )
            );

        } else {
            statusLabel.setText("AVAILABLE");
            statusLabel.setStyle(
                    "-fx-text-fill: #4CAF50;"
                            + "-fx-font-size: 12;"
                            + "-fx-font-weight: bold;"
            );
            toggleButton.setText("Block");
            toggleButton.setOnAction(event -> toggleBlock(
                            resource,
                            ResourceStatus.BLOCKED
                    )
            );
        }
        VBox actionBox = new VBox(5, statusLabel, toggleButton);
        actionBox.setAlignment(Pos.CENTER_RIGHT);

        card.getChildren().addAll(iconBox, textDetails, spacer, actionBox);
        return card;
    }

    private void toggleBlock(Resource resource, ResourceStatus newStatus) {
        resource.setStatus(newStatus);

        String key = normaliseId(resource.getId());

        if (newStatus == ResourceStatus.BLOCKED) {
            blockedIds.add(key);
        } else {
            blockedIds.remove(key);
        }
        saveBlockedIds();
        refreshList();
    }

    private void loadBlockedIds() {
        blockedIds.clear();

        File file = new File(BLOCKED_FILE);
        if (!file.exists()) {
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String id = line.trim();

                if (!id.isEmpty()) {
                    blockedIds.add(normaliseId(id));
                }
            }

        } catch (IOException exception) {
            System.err.println("Error reading blocked resources: " + exception.getMessage()
            );
        }
    }

    private void saveBlockedIds() {
        File file = new File(BLOCKED_FILE);

        if (file.getParentFile() != null) {
            file.getParentFile().mkdirs();
        }
        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            for (String id : new TreeSet<>(blockedIds)) {
                writer.println(id);
            }
        } catch (IOException exception) {
            System.err.println("Error saving blocked resources: " + exception.getMessage());
        }
    }

    private String friendlyBuilding(String code) {
        return switch (code.toUpperCase(Locale.ROOT)) {
            case "D" -> "Block D";
            case "E" -> "Block E";
            case "LAB" -> "Block D - Computer Labs";
            case "LIB" -> "Library";
            case "OUT" -> "Outdoor Sports";
            default -> code;
        };
    }

    // Converts resource ID to uppercase and removes blank spaces for comparison
    private String normaliseId(String id) {
        return id == null
                ? ""
                : id.trim().toUpperCase(Locale.ROOT);
    }

    // Checks whether an MCP response represents an error
    private boolean isErrorResponse(String response) {
        return response != null && response.trim().toUpperCase(Locale.ROOT).startsWith("ERROR:");
    }

    // Displays warning dialog to Admins
    private void showAlert(String message) {
        new Alert(Alert.AlertType.WARNING, message).showAndWait();
    }
}