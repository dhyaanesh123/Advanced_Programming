package com.campus.client;
import com.campus.client.controllers.Login;
import com.campus.client.llm.AnthropicClient;
import com.campus.client.llm.GeminiClient;
import com.campus.client.llm.LlmClient;
import com.campus.client.llm.OpenAiClient;
import com.campus.client.mcp.CampusMcpClient;
import com.campus.client.rag.RagService;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.slf4j.Logger;        // For log messages (.info, .warn, .error)
import org.slf4j.LoggerFactory; // Creates Logger
import java.net.URL;

/**
 * JavaFX host for the reference client. Resolves configuration, connects to the Campus MCP server
 * over HTTP/SSE on a background thread, builds the RAG stack, and hands everything.
 *
 * Configuration (all overridable):
 * {@code -Dmcp.server.url} or env {@code MCP_SERVER_URL} (default http://localhost:8080)
 * env {@code ANTHROPIC_API_KEY} (required for the RAG tab)
 * {@code -Danthropic.model} (default claude-sonnet-4-6)
 */

public final class App extends Application {

    private static final Logger log = LoggerFactory.getLogger(App.class);
    // Log information, warnings & errors

    private static final String DEFAULT_URL = "http://localhost:8080";
    private static final String DEFAULT_ANTHROPIC_MODEL = "claude-sonnet-4-6";
    private static final String DEFAULT_OPENAI_MODEL = "gpt-4o-mini";
    private static final String DEFAULT_GEMINI_MODEL = "gemini-2.5-flash";

    /** Default is anthropic. Change this to suit your need - anthropic, gemini, open-ai, google
        Remember to set the <PROVIDER>_API_Key value in your environment variable.
        Warning: DO NOT store API_Keys in your source code!
    **/
    private static final String DEFAULT_PROVIDER = "anthropic"; //gemini  //openai
    // Anthropic API Key is stored in Launcher's environment variable.

    private CampusMcpClient mcp;
    private LlmClient llmClient;
    private RagService ragService;
    private Login loginController;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {

        try {
            URL loginFXML = App.class.getResource("/login.fxml");

            if (loginFXML == null) {
                throw new IllegalStateException("login.fxml not found.");
            }
            FXMLLoader loader = new FXMLLoader(loginFXML);

            Parent root = loader.load();
            loginController = loader.getController();

            stage.setTitle("Resource Booking System");
            stage.setScene(new Scene(root));
            stage.show();

            Thread bootstrapThread = new Thread(this::bootstrap, "mcp-bootstrap");
            // Create a separate background thread

            bootstrapThread.setDaemon(true);
            /*
            Daemon Thread is a background-support thread that allow the program to terminate.
            "setDaemon(true)" allows Java to terminate the program after all non-daemon threads have finished.
             */

            bootstrapThread.start();

        } catch (Exception e) {
            log.error("Failed to start the Resource Booking System.", e);
            e.printStackTrace();    // Prints error details
            Platform.exit();        // Closes JavaFX application
        }

    }

    private void bootstrap() {

        try {
            String mcpUrl = firstNonBlank(
                    System.getProperty("mcp.server.url"),
                    System.getenv("MCP_SERVER_URL"),
                    DEFAULT_URL);
            /*
            Identify MCP server URL following this order:
            1. Java system property
            2. Environment variable
            3. Default application URL
             */

            log.info("Connecting to MCP server at {}", mcpUrl);

            mcp = new CampusMcpClient(mcpUrl);
            var init = mcp.connect();
            /*
            Create MCP client & established the connection
            "init" return information about the connected MCP server
             */

            llmClient = buildLlmClient();
            /*
            Create Anthropic LLM client
             */

            ragService = llmClient == null
                                    ? null
                                    : new RagService(mcp, llmClient);
            /*
            RagService requires MCP client & LLM client
             */

            String serverName = init.serverInfo().name();

            String llmStatus = llmClient == null
                            ? "Anthropic is disabled because " + "ANTHROPIC_API_KEY is missing."
                            : "Anthropic model: " + llmClient.model();
            /*
            Provide a log message whether AI function is activate or inactive
             */

            log.info("Connected to MCP server '{}'. {}", serverName, llmStatus);

            Platform.runLater(() -> {
                loginController.setMcpClient(mcp);
                loginController.setRagService(ragService);
            });
            /*
            Update JavaFX controllers
             */

        } catch (Exception exception) {
            log.error("Application bootstrap failed.", exception);

            Platform.runLater(() -> System.err.println("Could not connect to the MCP server. "
                                                        + "Make sure the server is running. "
                                                        + exception.getMessage())
            );
        }

    }

    /**
     * Builds an LLM client based on the {@code LLM_PROVIDER} setting and the appropriate API-key
     * environment variable. Returns {@code null} (RAG tab disabled) if no key is configured.
     */
    private LlmClient buildLlmClient() {

        String provider = firstNonBlank(System.getProperty("llm.provider"),
                System.getenv("LLM_PROVIDER"), DEFAULT_PROVIDER).toLowerCase();
        int maxTokens = 1024;

        switch (provider) {
            case "anthropic" -> {
                String key = firstNonBlank(System.getProperty("anthropic.apiKey"),
                        System.getenv("ANTHROPIC_API_KEY"), null);
                if (key == null) return null;
                String model = firstNonBlank(System.getProperty("anthropic.model"), DEFAULT_ANTHROPIC_MODEL);
                return new AnthropicClient(key, model, maxTokens);
            }

            case "openai" -> {
                String key = firstNonBlank(System.getProperty("openai.apiKey"),
                        System.getenv("OPENAI_API_KEY"), null);
                if (key == null) return null;
                String model = firstNonBlank(System.getProperty("openai.model"), DEFAULT_OPENAI_MODEL);
                return new OpenAiClient(key, model, maxTokens);
            }

            case "gemini", "google" -> {
                String key = firstNonBlank(System.getProperty("gemini.apiKey"),
                        System.getenv("GEMINI_API_KEY"), System.getenv("GOOGLE_API_KEY"), null);
                if (key == null) return null;
                String model = firstNonBlank(System.getProperty("gemini.model"), DEFAULT_GEMINI_MODEL);
                return new GeminiClient(key, model, maxTokens);
            }

            default -> {
                log.warn("Unknown LLM_PROVIDER '{}'; RAG tab disabled.", provider);
                return null;
            }
        }

    }
    private static String firstNonBlank(String... values) {

        for (String v : values) {               // Loop through passed String
            if (v != null && !v.isBlank()) {    // Check first value that is not null and blank
                return v;                       // Return the first value
            }
        }
        return null;                            // Return null when none of the provided values are valid

    }

    @Override
    public void stop() {

        if (mcp != null) {
            mcp.close();                                        // Terminate connection with MCP server
            System.out.println("Disconnected from server.");
        }
        Platform.exit();

    }

}