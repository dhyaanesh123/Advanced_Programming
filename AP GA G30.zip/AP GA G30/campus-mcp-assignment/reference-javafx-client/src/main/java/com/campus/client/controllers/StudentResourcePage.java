package com.campus.client.controllers;

import com.campus.client.mcp.CampusMcpClient;
import com.campus.client.models.Booking;
import com.campus.client.models.BookingStatus;
import com.campus.client.models.Resource;
import com.campus.client.models.ResourceStatus;
import com.campus.client.repositories.BookingRepository;
import com.campus.client.services.AuthService;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class StudentResourcePage {

    @FXML
    private VBox resourceListContainer;

    /*
    Search field declared in Resource Page(Student).fxml.
    The student can search using a full or partial resource ID.
    */
    @FXML
    private TextField searchField;

    private BookingRepository bookingRepository;
    private AuthService authService;
    private CampusMcpClient mcpClient;
    private static final String BLOCKED_FILE = "data/blocked_resources.csv";

    private final Set<String> blockedIds = new HashSet<>();
    private final Set<String> mcpBookableIds = new HashSet<>();

    /*
    Stores the complete resource list retrieved from campus://facilities.
    Searching filters this list without repeatedly contacting the MCP server.
    */
    private final List<Resource> allResources = new ArrayList<>();

    @FXML
    public void initialize() {
        bookingRepository = new BookingRepository();
        loadBlockedIds();

        if (resourceListContainer != null) {
            resourceListContainer.setSpacing(10);
        }

        // Refresh the displayed list whenever the student types into the resource search field
        if (searchField != null) {
            searchField.textProperty().addListener(
                    (observable, oldText, newText) -> refreshResourceList()
            );
        }
    }

    public void setAuthService(AuthService authService) {
        this.authService = authService;
    }

    public void setMcpClient(CampusMcpClient mcpClient) {
        if (mcpClient == null) {
            showResourceMessage("Campus resource data is unavailable because " + "the MCP client was not provided.");
            return;
        }
        this.mcpClient = mcpClient;
        loadBlockedIds();
        loadResourceCards();
    }

    private void loadResourceCards() {
        if (resourceListContainer == null) {
            System.err.println("resourceListContainer was not injected.");
            return;
        }

        resourceListContainer.getChildren().clear();
        resourceListContainer.setSpacing(10);

        if (mcpClient == null) {
            showResourceMessage("Not connected to the campus server.");
            return;
        }
        loadBlockedIds();
        loadMcpBookableIds();

        allResources.clear();
        allResources.addAll(getAllResourcesFromFacilities());

        if (allResources.isEmpty()) {
            showResourceMessage("No campus resources were found.");
            return;
        }

        refreshResourceList();
    }

    /*
    Displays resources whose IDs contain the student's search text.
    The search is case-insensitive and supports partial IDs.
    */
    private void refreshResourceList() {
        if (resourceListContainer == null) {
            return;
        }

        resourceListContainer.getChildren().clear();

        String searchText = searchField == null
                ? ""
                : normaliseId(searchField.getText());

        int matchCount = 0;

        for (Resource resource : allResources) {
            String resourceId = normaliseId(resource.getId());

            if (!searchText.isEmpty() && !resourceId.contains(searchText)) {
                continue;
            }

            resourceListContainer.getChildren().add(buildResourceCard(resource));
            matchCount++;
        }

        if (matchCount == 0) {
            Label noMatchLabel = new Label("No resource ID matches " + searchField.getText().trim() + ".");

            noMatchLabel.setWrapText(true);
            noMatchLabel.setStyle("-fx-text-fill: #aaaaaa;"
                                + "-fx-font-size: 14;"
                                + "-fx-padding: 20;"
            );

            resourceListContainer.getChildren().add(noMatchLabel);
        }
    }

    private List<Resource> getAllResourcesFromFacilities() {
        List<Resource> resources = new ArrayList<>();

        try {
            String text = mcpClient.readResource("campus://facilities");

            boolean inTable = false;

            for (String line : text.split("\\R")) {
                String trimmed = line.trim();

                if (trimmed.equalsIgnoreCase("[Bookable Resources]")) {
                    inTable = true;
                    continue;
                }

                if (!inTable) {
                    continue;
                }

                if (trimmed.startsWith("[")) {
                    break;
                }

                if (trimmed.isBlank() || trimmed.toUpperCase(Locale.ROOT).startsWith("ROOM")) {
                    continue;
                }

                String[] parts = trimmed.split("\\|");

                if (parts.length < 4) {
                    continue;
                }

                String id = parts[0].trim();
                String type = parts[1].trim();
                String building = parts[3].trim();
                String key = normaliseId(id);

                ResourceStatus status = blockedIds.contains(key)
                        ? ResourceStatus.BLOCKED
                        : ResourceStatus.AVAILABLE;

                resources.add(new Resource(
                        id,
                        id,
                        friendlyBuilding(building),
                        status,
                        mcpBookableIds.contains(key),
                        type));
            }

        } catch (Exception exception) {
            System.err.println("Could not read facilities: "  + exception.getMessage());
            exception.printStackTrace();
        }
        return resources;
    }

    private void loadMcpBookableIds() {
        mcpBookableIds.clear();

        if (mcpClient == null) {
            return;
        }

        try {
            String response = mcpClient.callTool("check_room_availability", Map.of("date", LocalDate.now().plusDays(1).toString()));

            if (response == null || response.isBlank() || isErrorResponse(response)) {
                return;
            }
            for (String line : response.split("\\R")) {
                String trimmed = line.trim();
                if (trimmed.isBlank() || !trimmed.contains("->") || trimmed.toLowerCase(Locale.ROOT).startsWith("availability on")) {
                    continue;
                }
                String[] tokens = trimmed.split("\\s+");
                if (tokens.length > 0) {
                    mcpBookableIds.add(normaliseId(tokens[0]));
                }
            }

        } catch (Exception exception) {
            System.err.println("Could not load MCP-bookable IDs: " + exception.getMessage());
        }
    }

    private HBox buildResourceCard(Resource resource) {
        HBox card = new HBox(15);
        card.setStyle("-fx-background-color: #2b2b2b;"
                    + "-fx-padding: 15;"
                    + "-fx-background-radius: 8;");
        card.setPrefHeight(80);
        card.setAlignment(Pos.CENTER_LEFT);

        String type = resource.getType().toLowerCase(Locale.ROOT);

        String iconText = "📍";
        if (type.contains("room"))
            iconText = "👥";
        else if (type.contains("pod"))
            iconText = "📖";
        else if (type.contains("lab"))
            iconText = "🖥️";
        else if (type.contains("court") || type.contains("sport"))
            iconText = "⚽";

        Label icon = new Label(iconText);
        icon.setStyle("-fx-font-size: 30;");

        Label nameLabel = new Label(resource.getName());
        nameLabel.setStyle("-fx-text-fill: white;"
                            + "-fx-font-weight: bold;"
                            + "-fx-font-size: 16;");

        Label locationLabel = new Label(resource.getLocation());
        locationLabel.setStyle("-fx-text-fill: #aaaaaa;"
                                + "-fx-font-size: 12;");

        VBox textDetails = new VBox(5, nameLabel, locationLabel);
        textDetails.setAlignment(Pos.CENTER_LEFT);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label statusLabel = new Label();
        Button bookButton = new Button();

        if (resource.getStatus() == ResourceStatus.BLOCKED) {

            statusLabel.setText("BLOCKED");
            statusLabel.setStyle("-fx-text-fill: #F44336;"
                                + "-fx-font-weight: bold;");

            bookButton.setText("Unavailable");
            bookButton.setDisable(true);

        } else if (resource.isMcpBookable()) {

            statusLabel.setText("BOOKABLE");
            statusLabel.setStyle("-fx-text-fill: #4CAF50;"
                                + "-fx-font-weight: bold;");

            bookButton.setText("Book Now");
            bookButton.setDisable(false);
            bookButton.setStyle("-fx-background-color: #2196F3;"
                                + "-fx-text-fill: white;"
                                + "-fx-font-weight: bold;"
                                + "-fx-cursor: hand;");

            bookButton.setOnAction(event -> showBookingDialog(resource));

        } else {
            statusLabel.setText("VIEW ONLY");
            statusLabel.setStyle("-fx-text-fill: #FFB74D;"
                                + "-fx-font-weight: bold;");

            bookButton.setText("Not Bookable");
            bookButton.setDisable(true);
            bookButton.setTooltip(new Tooltip("The MCP booking server does not recognise this resource ID."));
        }

        if (bookButton.isDisabled()) {
            bookButton.setStyle("-fx-background-color: #555555;"
                                + "-fx-text-fill: #aaaaaa;");
        }

        VBox actionBox = new VBox(5, statusLabel, bookButton);
        actionBox.setAlignment(Pos.CENTER_RIGHT);

        card.getChildren().addAll(icon, textDetails, spacer, actionBox);
        return card;
    }

    private void showBookingDialog(Resource resource) {
        if (resource == null) {
            return;
        }

        if (resource.getStatus() == ResourceStatus.BLOCKED) {
            showAlert(Alert.AlertType.WARNING, "This resource was blocked by an administrator.");
            return;
        }
        if (!resource.isMcpBookable()) {
            showAlert(Alert.AlertType.WARNING, "This resource is not supported by the MCP booking server.");
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Book Campus Resource");
        dialog.setHeaderText("Booking: " + resource.getName() + "\nLocation: " + resource.getLocation()
        );

        DatePicker datePicker = new DatePicker(LocalDate.now());

        ComboBox<String> timeComboBox = new ComboBox<>();
        timeComboBox.setPromptText("Select Time");

        loadAvailableTimes(timeComboBox, datePicker.getValue());

        datePicker.valueProperty().addListener(
                (observable, oldDate, newDate) -> {
                    if (newDate != null) {
                        loadAvailableTimes(timeComboBox, newDate
                        );
                    }
                }
        );

        VBox layout = new VBox(10, new Label("Select Date:"), datePicker, new Label("Select Time:"), timeComboBox);

        dialog.getDialogPane().setContent(layout);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();

        if (result.isEmpty() || result.get() != ButtonType.OK) {
            return;
        }

        LocalDate selectedDate = datePicker.getValue();

        String selectedTimeText = timeComboBox.getValue();

        if (selectedDate == null) {
            showAlert(Alert.AlertType.WARNING, "Please select a booking date.");
            return;
        }

        if (selectedDate.isBefore(LocalDate.now())) {
            showAlert(Alert.AlertType.ERROR, "You cannot book a past date.");
            return;
        }

        if (selectedTimeText == null || selectedTimeText.isBlank()) {
            showAlert(Alert.AlertType.WARNING, "Please select a booking time.");
            return;
        }

        if (authService == null || authService.getCurrentUser() == null) {
            showAlert(Alert.AlertType.ERROR, "No authenticated student was found.");
            return;
        }

        String studentId = authService.getCurrentUser().getId();

        LocalTime startTime = LocalTime.parse(selectedTimeText);

        if (selectedDate.equals(LocalDate.now()) && !startTime.isAfter(LocalTime.now())) {
            showAlert(Alert.AlertType.ERROR, "You cannot book a time slot in the past.");
            return;
        }

        int duration = isSportsResource(resource) ? 1 : 2;

        LocalTime endTime = startTime.plusHours(duration);

        try {
            String availabilityResponse = mcpClient.callTool("check_room_availability",
                    Map.of("date", selectedDate.toString()));

            if (availabilityResponse == null || availabilityResponse.isBlank() || isErrorResponse(
                    availabilityResponse
            )) {
                showAlert(Alert.AlertType.ERROR, availabilityResponse == null
                        ? "The availability response was empty."
                        : availabilityResponse
                );
                return;
            }

            String availabilityStatus = findAvailabilityStatus(availabilityResponse, resource.getId());

            if (availabilityStatus == null) {
                showAlert(Alert.AlertType.ERROR, "The booking server does not recognise '" + resource.getId() + "'.");
                return;
            }

            if (!availabilityStatus.equalsIgnoreCase("free")) {
                showAlert(Alert.AlertType.WARNING, resource.getId() + " is " + availabilityStatus + " on " + selectedDate + ".");
                return;
            }

            List<Booking> studentBookings = bookingRepository.findBookingsByStudentId(studentId);

            long activeCount = studentBookings.stream().filter(
                    booking ->
                            booking.getStatus() == BookingStatus.CONFIRMED &&
                                    !booking.getBookingDate().isBefore(LocalDate.now())).count();

            if (activeCount >= 3) {
                showAlert(Alert.AlertType.WARNING, "You can only have three active bookings.");
                return;
            }

            List<Booking> existingBookings = bookingRepository.findBookingsByResourceAndDate(resource.getId(), selectedDate);

            for (Booking booking : existingBookings) {
                boolean overlap = startTime.isBefore(booking.getEndTime()) && endTime.isAfter(booking.getStartTime());
                if (overlap) {
                    showAlert(Alert.AlertType.ERROR,
                            "This resource is already booked from " + booking.getStartTime() + " to " + booking.getEndTime() + ".");
                    return;
                }
            }

            String serverResponse = mcpClient.callTool("book_resource",
                    Map.of("studentId", studentId,
                            "resourceId", resource.getId(),
                            "date", selectedDate.toString(),
                            "startTime", startTime.toString(),
                            "endTime", endTime.toString()
                    )
            );

            if (serverResponse == null || serverResponse.isBlank() || isErrorResponse(serverResponse)) {
                showAlert(Alert.AlertType.ERROR, "Server returned: " + serverResponse);
                return;
            }

            Booking booking = new Booking(bookingRepository.generateBookingId(), studentId, resource.getId(), selectedDate, startTime, endTime, BookingStatus.CONFIRMED);
            bookingRepository.addBooking(booking);

            Alert success = new Alert(Alert.AlertType.INFORMATION, "Booking successful.\n\n" + serverResponse);
            success.setHeaderText("Resource booked successfully");
            success.showAndWait();

            loadResourceCards();

        } catch (Exception exception) {
            exception.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Could not complete the booking.\n\n" + exception.getMessage());
        }
    }

    private String findAvailabilityStatus(String response, String resourceId) {
        String target = normaliseId(resourceId);

        for (String line : response.split("\\R")) {
            String trimmed = line.trim();

            if (!trimmed.contains("->")) {
                continue;
            }

            String[] tokens = trimmed.split("\\s+");

            if (tokens.length == 0 || !normaliseId(tokens[0]).equals(target)) {
                continue;
            }

            int arrow = trimmed.lastIndexOf("->");

            return arrow < 0
                    ? null
                    : trimmed.substring(arrow + 2).trim();
        }
        return null;
    }

    private void loadAvailableTimes(ComboBox<String> comboBox, LocalDate date) {
        comboBox.getItems().clear();

        if (date == null) {
            comboBox.setPromptText("Select a date first");
            return;
        }

        List<String> times = Arrays.asList(
                "08:00",
                "10:00",
                "12:00",
                "14:00",
                "16:00",
                "18:00"
        );

        if (date.isBefore(LocalDate.now())) {
            comboBox.setPromptText("Cannot book past dates");
            return;
        }

        for (String time : times) {
            LocalTime slot = LocalTime.parse(time);

            if (!date.equals(LocalDate.now()) || slot.isAfter(LocalTime.now())) {
                comboBox.getItems().add(time);
            }
        }

        comboBox.setPromptText(comboBox.getItems().isEmpty()
                ? "No slots left today"
                : "Select Time"
        );
    }

    private boolean isSportsResource(Resource resource) {
        String type = resource.getType().toLowerCase(Locale.ROOT);
        return type.contains("court") || type.contains("sport");
    }

    private void loadBlockedIds() {
        blockedIds.clear();

        File file = new File(BLOCKED_FILE);
        if (!file.exists()) {
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String id = line.trim();

                if (!id.isEmpty()) {
                    blockedIds.add(
                            normaliseId(id)
                    );
                }
            }

        } catch (IOException exception) {
            System.err.println("Error reading blocked resources: " + exception.getMessage());
        }
    }

    private String friendlyBuilding(String code) {
        return switch (code.toUpperCase(Locale.ROOT)) {
            case "D" -> "Block D";
            case "E" -> "Block E";
            case "LAB" -> "Block D - Computer Labs";
            case "LIB" -> "Library";
            case "OUT" -> "Outdoor Sports";
            default -> code;
        };
    }

    private String normaliseId(String id) {
        return id == null
                ? ""
                : id.trim().toUpperCase(Locale.ROOT);
    }

    private boolean isErrorResponse(String response) {
        return response != null && response.trim().toUpperCase(Locale.ROOT).startsWith("ERROR:");
    }

    private void showResourceMessage(String message) {
        if (resourceListContainer == null) {
            System.err.println(message);
            return;
        }
        resourceListContainer.getChildren().clear();

        Label label = new Label(message);
        label.setWrapText(true);
        label.setStyle("-fx-text-fill: #aaaaaa;"
                + "-fx-font-size: 14;"
                + "-fx-padding: 20;"
        );

        resourceListContainer.getChildren().add(label);
    }

    private void showAlert(Alert.AlertType type, String message) {
        new Alert(type, message).showAndWait();
    }

}