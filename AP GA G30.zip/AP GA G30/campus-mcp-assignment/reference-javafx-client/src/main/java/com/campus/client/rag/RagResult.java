package com.campus.client.rag;

public record RagResult(String answer, String retrievedContext) {

    public RagResult {

        /*
         Replaces null values with empty strings
         so callers can safely use methods such as isBlank().
         */

        if (answer == null) {
            answer = "";
        }

        if (retrievedContext == null) {
            retrievedContext = "";
        }
    }

}
