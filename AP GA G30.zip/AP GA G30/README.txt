-----------------------------------------
AP Group Assignment Group 30


Steps to launch program:
1. Extract the zip folder.
2. Open any IDEs (Recommended: IntelliJ)
3. Open project, and select campus-info-mcp-server separately
4. Open project, and select reference-javafx-client separately as well.
5. Run CampusMcpServer first(inside campus-info-mcp-server folder).
6. Lastly, run Launcher(inside reference-javafx-client folder).


Program details:
For Admin access, please use the provided Admin ID and password below:
Admin ID : admin001
Password : admin123

For Student access, please use the provided Student ID and password below:
Student ID : 0000001
Password : password_arief


IMPORTANT NOTE:
For the booking resources for student page, only three resources are bookable (KA-P1, KA-P2, SP-B1).
This is due to the incorrect reading of hyphens in the MCP server file. Since we are not allowed to edit or modify the MCP server
codes, only three resources are allowed for booking.


Note for AI Assistant for our application:
Ask Clear Questions
Type your question clearly and provide enough details. Avoid using unclear or incomplete phrases.

1. Ask Campus-Related Questions
* Campus facilities information
* Resource booking procedures
* Booking policies and rules
* Campus handbook information
* Frequently asked questions

2. Provide Specific Details When Needed
* Resource type
* Date or time period
* Location (if applicable)

3. Verify Important Information

* The AI assistant must always verify important details before making decisions.
* If information is unavailable, the assistant will inform you instead of guessing.

4. Avoid Unrelated Questions

The AI Assistant may not provide useful responses for:

* General internet searches
* Personal advice
* Non-campus-related topics
* Questions unrelated to facilities, resources, or booking

5. Be Patient During Responses

* Complex questions may require additional processing time.
* Do not repeatedly send the same question while the assistant is generating a response