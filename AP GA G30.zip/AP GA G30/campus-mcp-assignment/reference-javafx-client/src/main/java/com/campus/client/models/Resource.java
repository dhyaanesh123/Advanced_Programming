package com.campus.client.models;

public class Resource {
    private String id;
    private String name;
    private String location;
    private ResourceStatus status;
    private boolean mcpBookable;
    private String type;

    public Resource(String id, String name, String location, ResourceStatus status, boolean mcpBookable, String type) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.status = status;
        this.mcpBookable = mcpBookable;
        this.type = type;
    }

    public String getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    public String getLocation(){
        return location;
    }

    public ResourceStatus getStatus(){
        return status;
    }

    public boolean isMcpBookable() {
        return mcpBookable;
    }

    public String getType(){
        return type;
    }

    public void setStatus(ResourceStatus status){
        this.status = status;
    }

}
