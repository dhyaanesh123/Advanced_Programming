package com.campus.client.services;

import com.campus.client.rag.RagResult;
import com.campus.client.rag.RagService;

import javafx.concurrent.Task;
import java.util.Objects;
import java.util.function.Consumer;

public class AiTaskService {

    private Task<RagResult> currentTask;
    // Stores the currently running AI task

    public void startStreamingTask(         // Starts the AI request that returns the response gradually through text chunks
            String question,
            String topic,
            String conversationHistory,
            RagService ragService,
            Consumer<String> onTextChunk,
            Consumer<RagResult> onSucceeded,
            Consumer<Throwable> onFailed
    ) {
        Objects.requireNonNull(ragService, "RagService cannot be null.");
        Objects.requireNonNull(onTextChunk, "Text chunk callback cannot be null.");
        Objects.requireNonNull(onSucceeded, "Success callback cannot be null.");
        Objects.requireNonNull(onFailed, "Failure callback cannot be null.");
        /*
        Ensures required service were provided before starting the task
         */

        if (isRunning()) {
            throw new IllegalStateException("An AI request is already running.");   // Prevent multiple requests from running
        }

        currentTask = new Task<>() {        // Create a  background task

            @Override
            protected RagResult call() throws Exception {

                // Ask RagService to retrieve relevant context & stream the AI response
                return ragService.streamAsk(question, topic, conversationHistory,
                        chunk -> {

                            if (!isCancelled()) {           // Conctinue passing the text chunks while the task is not cancelled
                                onTextChunk.accept(chunk);

                            }
                        }
                );

            }
        };

        currentTask.setOnSucceeded(
                event -> onSucceeded.accept(currentTask.getValue())
        );
        // Runs after RagService successfully completes the entire streaming request.

        currentTask.setOnFailed(
                event -> onFailed.accept(currentTask.getException())
        );
        // Runs when an exception occurs while processing the AI request

        currentTask.setOnCancelled(
                event -> {
            /*
            No additional action is required when the task is intentionally cancelled, such as during logout.
             */
        });

        Thread thread = new Thread(currentTask, "ai-rag-streaming-task");
        // Runs "currentTask" on a separate background thread

        thread.setDaemon(true);
        thread.start();
    }

    public boolean isRunning() {            // Checks whether an AI request is currently running
        return currentTask != null && currentTask.isRunning();
    }

    public void cancelCurrentTask() {       // Cancels current AI request when it is still running
        if (currentTask != null && currentTask.isRunning()) {
            currentTask.cancel(true);       // Passes interruption request of the background thread
        }
    }

}