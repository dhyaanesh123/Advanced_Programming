package com.campus.client.repositories;

import com.campus.client.models.User;
import com.campus.client.models.Role;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {

    private static final String USERS_FILE = "data/users.csv";
    private static final String PROFILES_FILE = "data/student_profiles.csv";
    private List<User> users;

    public UserRepository() {
        this.users = new ArrayList<>();
        loadUsers();
        createDefaultAdminIfNeeded();
    }

    // Create default admin if none exists
    private void createDefaultAdminIfNeeded() {
        if (users.isEmpty()) {
            User admin = new User("admin001", "admin123", Role.ADMIN);
            admin.setFullName("System Administrator");
            admin.setEmail("admin@campus.edu");
            admin.setProgramme("N/A");
            users.add(admin);
            saveAll();
        }
    }

    // Load all user information
    public void loadUsers() {
        users.clear();
        loadAuthFile();
        loadProfiles();
    }

    // Loads User ID, password & role from users.csv
    private void loadAuthFile() {
        File file = new File(USERS_FILE);

        if (!file.exists()) {
            System.out.println("Users file not found, will create default admin.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = reader.readLine()) != null) {

                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(",");

                if (parts.length == 3) {
                    users.add(new User(parts[0].trim(), parts[1].trim(), Role.valueOf(parts[2].trim())));
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading users: " + e.getMessage());
        }
    }

    // Load Students profile information from student_profiles.csv
    private void loadProfiles() {
        File file = new File(PROFILES_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = reader.readLine()) != null) {

                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(",");

                if (parts.length == 4) {
                    String id = parts[0].trim();

                    // Match student profile record to the relevant student
                    for (User user : users) {
                        if (user.getId().equals(id)) {

                            user.setFullName(parts[1].trim());
                            user.setEmail(parts[2].trim());
                            user.setProgramme(parts[3].trim());
                            break;                              // Stops searching once matched

                        }
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading profiles: " + e.getMessage());
        }
    }

    // Save both authentication & profile information
    public void saveAll() {
        saveAuthFile();
        saveProfileFile();
    }

    // Rewrites users.csv with current contents of users list
    private void saveAuthFile() {
        File file = new File(USERS_FILE);
        file.getParentFile().mkdirs();

        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            for (User user : users) {
                writer.println(user.toAuthCsvLine());
            }
        } catch (IOException e) {
            System.err.println("Error saving users: " + e.getMessage());
        }
    }

    // Rewrites student_profiles.csv using profile information belonging to the student
    private void saveProfileFile() {
        File file = new File(PROFILES_FILE);
        file.getParentFile().mkdirs();

        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {

            for (User user : users) {

                // Only student profiles with a non-empty full name are stored
                if (user.getRole() == Role.STUDENT && !user.getFullName().isEmpty()) {
                    writer.println(user.toProfileCsvLine());
                }
            }
        } catch (IOException e) {
            System.err.println("Error saving profiles: " + e.getMessage());
        }
    }

    // Searches for a user with matching credentials
    public User findByCredentials(String id, String password) {
        for (User user : users) {
            if (user.getId().equals(id) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    // Check if ID already exists
    public boolean existsById(String id) {
        for (User user : users) {
            if (user.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }

    // Add user & update relevant csv files
    public void addUser(User user) {
        users.add(user);
        saveAll();
    }

    // Returns a new list containing only students
    public List<User> getAllStudents() {
        List<User> students = new ArrayList<>();
        for (User user : users) {
            if (user.getRole() == Role.STUDENT) {
                students.add(user);
            }
        }
        return students;
    }

}