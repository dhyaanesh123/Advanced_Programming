package com.campus.client.services;

public class ChatService {

    private StringBuilder conversation = new StringBuilder();
    /*
     conversation stores the complete conversation history.
     StringBuilder is used due to frequent addition of messages.
     */

    public String getConversation() {
        return conversation.toString(); // Return complete conversation as a String
    }


    public void addMessage(String message) {
        conversation.append(message);   // Add new messages to the end of current conversation history
    }

    public void setConversation(String conversation) {
        this.conversation = new StringBuilder(conversation);
    }

    public String getRecentConversation(int maximumLines) {
        /*
         Returns the most recent lines from conversation history.
         Useful when sending context to the AI without including the whole conversation history.
         */

        String fullConversation = conversation.toString();

        if (fullConversation.isBlank()) {
            return "";      // Returns an empty String when no messages are found in conversation
        }

        String[] lines = fullConversation.split("\\R");
        /*
        Split the conversation into separate lines.
        "\\R" supports different formats for line-ending.
         */

        int startIndex = Math.max(0, lines.length - maximumLines);
        /*
        Identify where the recent conversation begins.
        "Math.max" is used to prevent negative index values when conversation contains fewer lines than expected.
         */

        StringBuilder recent = new StringBuilder();

        for (int index = startIndex; index < lines.length; index++) {
            recent.append(lines[index]).append(System.lineSeparator());     // Append recent lines into a new StringBuilder

        }
        return recent.toString().trim();                                    // Remove unnecessary line separator before returning recent conversation
    }

    public void clearConversation() {
        // Clear conversation history while retaining the same StringBuilder objects

        conversation.setLength(0);
    }

}