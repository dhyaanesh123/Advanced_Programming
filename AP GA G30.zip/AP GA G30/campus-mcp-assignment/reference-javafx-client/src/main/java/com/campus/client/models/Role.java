package com.campus.client.models;

public enum Role {
    STUDENT,
    ADMIN
}
