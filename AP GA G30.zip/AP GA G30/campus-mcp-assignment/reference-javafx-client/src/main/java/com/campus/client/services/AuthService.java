package com.campus.client.services;

import com.campus.client.models.Role;
import com.campus.client.models.User;
import com.campus.client.repositories.UserRepository;

public class AuthService {

    private UserRepository userRepository;  // Access stored user records
    private User currentUser;               // Store the user who is currently logged in

    public AuthService() {
        this.userRepository = new UserRepository();
    }

    public boolean login(String id, String password) {
        // Authentication method

        User user = userRepository.findByCredentials(id, password);
        // Authenticate a user using the provided Student ID & password

        if (user != null) {
            currentUser = user;
            return true;            // Returns true if matching credentials are found
        }
        return false;               // Returns false if credentials are invalid
    }

    public void logout() {
        // Ends user current session

        currentUser = null;         // Set "currentUser" back to null
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public boolean isAdmin() {
        // Check whether current user has Admin role

        return currentUser != null && currentUser.getRole() == Role.ADMIN;
    }

    public boolean isStudent() {
        // Check whether current user has Student role

        return currentUser != null && currentUser.getRole() == Role.STUDENT;
    }

}