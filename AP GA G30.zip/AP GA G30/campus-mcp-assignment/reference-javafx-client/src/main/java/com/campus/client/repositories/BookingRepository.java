package com.campus.client.repositories;

import com.campus.client.models.Booking;
import com.campus.client.models.BookingStatus;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BookingRepository {

    private static final String BOOKINGS_FILE = "data/bookings.csv";


    private final List<Booking> bookings;
    // Stores bookings loaded from bookings.csv


    public BookingRepository() {
        this.bookings = new ArrayList<>();
        loadBookings();
    }

    // Retrieve booking records from bookings.csv & load into booking list
    public void loadBookings() {
        bookings.clear();   // Clear existing list to prevent duplicated records

        File file = new File(BOOKINGS_FILE);

        // No bookings to load when file does not exist
        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();

                // Ignore empty lines in bookings.csv
                if (line.isEmpty()) {
                    continue;
                }

                String[] parts = line.split(",");

                // Valid record must contain
                if (parts.length == 7) {
                    bookings.add(new Booking(
                                    parts[0].trim(),                            // Booking ID
                                    parts[1].trim(),                            // Student ID
                                    parts[2].trim(),                            // Resource ID
                                    LocalDate.parse(parts[3].trim()),           // Booking Date
                                    LocalTime.parse(parts[4].trim()),           // Start Time
                                    LocalTime.parse(parts[5].trim()),           // End Time
                                    BookingStatus.valueOf(parts[6].trim())      // Booking Status
                            )
                    );
                }
            }

        } catch (IOException exception) {
            System.err.println("Error loading bookings: " + exception.getMessage());
        }
    }

    // Rewrite bookings.csv with current contents of booking list
    public void saveAll() {
        File file = new File(BOOKINGS_FILE);

        File parentDirectory = file.getParentFile();
        // Create data directory when it does not exist

        if (parentDirectory != null) {
            parentDirectory.mkdirs();
        }

        try (
                PrintWriter writer = new PrintWriter(new FileWriter(file))
        ) {
            for (Booking booking : bookings) {
                writer.println(booking.toCsvLine()
                );
            }

        } catch (IOException exception) {
            System.err.println("Error saving bookings: " + exception.getMessage());
        }
    }

    // Add new booking to the list & instantly update bookings.csv
    public void addBooking(
            Booking booking
    ) {
        bookings.add(booking);
        saveAll();
    }

    // Change Confirmed bookings to Completed after passing current date & time
    public void updateCompletedBookings() {
        LocalDateTime now = LocalDateTime.now();

        boolean statusChanged = false;

        for (Booking booking : bookings) {
            LocalDateTime bookingEnd = LocalDateTime.of(booking.getBookingDate(), booking.getEndTime());

            // Only Confirmed bookings are automatically updated to Completed
            if (booking.getStatus() == BookingStatus.CONFIRMED && !bookingEnd.isAfter(now)) {
                booking.setStatus(BookingStatus.COMPLETED);
                statusChanged = true;
            }
        }
        // Rewrite bookings.csv
        if (statusChanged) {
            saveAll();
        }
    }

    // Returns all bookings relevant to the Student
    public List<Booking> findBookingsByStudentId(String studentId) {
        return bookings.stream().filter(
                        booking ->
                                booking.getStudentId().equals(studentId)).collect(Collectors.toList());
    }

    // Check a proposed booking if it overlaps an existing Confirmed booking
    public List<Booking> findBookingsByResourceAndDate(String resourceId, LocalDate date) {
        return bookings.stream().filter(
                        booking ->
                                booking.getResourceId().equals(resourceId)
                                        && booking.getBookingDate().equals(date)
                                        && booking.getStatus()
                                        == BookingStatus.CONFIRMED
                ).collect(Collectors.toList());
    }


    // Search for a booking using Booking ID
    public Booking findById(String bookingId) {
        for (Booking booking : bookings) {
            if (booking.getBookingId().equals(bookingId)) {
                return booking;
            }
        }
        return null;
    }

    // Cancels a Confirmed booking using Booking ID
    public boolean cancelBooking(String bookingId) {
        Booking booking = findById(bookingId);

        if (booking == null || booking.getStatus() != BookingStatus.CONFIRMED) {    // Completed / Cancelled bookings cannot be cancelled again
            return false;
        }

        booking.setStatus(BookingStatus.CANCELLED);
        saveAll();
        return true;
    }

    // Generate Booking IDs
    public String generateBookingId() {
        return "BKG-"
                + (bookings.size() + 1001);
    }

}