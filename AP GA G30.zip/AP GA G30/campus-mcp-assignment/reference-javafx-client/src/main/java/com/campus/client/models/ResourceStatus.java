package com.campus.client.models;

public enum ResourceStatus {
    AVAILABLE,
    BOOKED,
    BLOCKED
}
