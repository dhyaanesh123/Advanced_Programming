package com.campus.client.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Objects;
import java.util.function.Consumer;

public final class AnthropicClient implements LlmClient {

    private static final String ENDPOINT = "https://api.anthropic.com/v1/messages";
    private static final String ANTHROPIC_VERSION = "2023-06-01";

    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(20)).build();

    // Converts Java objects into JSON & parses JSON responses returned by Anthropic
    private final ObjectMapper mapper = new ObjectMapper();

    private final String apiKey;
    private final String model;
    private final int maxTokens;

    public AnthropicClient(String apiKey, String model, int maxTokens) {
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalArgumentException("Missing Anthropic API key (set ANTHROPIC_API_KEY).");
        }
        this.apiKey = apiKey;
        this.model = model;
        this.maxTokens = maxTokens;
    }

    @Override
    public String complete(String systemPrompt, String userPrompt) throws IOException, InterruptedException {

        ObjectNode body = buildRequestBody(systemPrompt, userPrompt, false);
        HttpRequest request = buildRequest(body);

        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() / 100 != 2) {
            throw new IOException("Anthropic API error "
                                    + response.statusCode()
                                    + ": "
                                    + response.body()
            );
        }

        JsonNode content = mapper.readTree(response.body()).path("content");
        StringBuilder output = new StringBuilder();

        for (JsonNode block : content) {
            if ("text".equals(block.path("type").asText())) {
                output.append(block.path("text").asText());
            }
        }
        return output.toString();
    }

    /*
    Sends a streaming request to Anthropic.
    Anthropic returns Server-Sent Events. Each text delta is forwarded immediately through onTextChunk so the UI can display the answer gradually.
    */
    @Override
    public void streamComplete(String systemPrompt, String userPrompt, Consumer<String> onTextChunk) throws IOException, InterruptedException {

        Objects.requireNonNull(onTextChunk, "Text chunk callback cannot be null.");

        // Create request body with streaming enabled
        ObjectNode body = buildRequestBody(systemPrompt, userPrompt, true);
        HttpRequest request = buildRequest(body);

        // Receives response body as InputStream so events can be read while Anthropic is generating
        HttpResponse<InputStream> response = http.send(request, HttpResponse.BodyHandlers.ofInputStream());

        // try-with-resources automatically closes the response stream after request finishes
        try (InputStream responseBody = response.body()) {
            if (response.statusCode() / 100 != 2) {
                String errorBody = new String(responseBody.readAllBytes(), StandardCharsets.UTF_8);

                // Throw complete error response when request is not succesful
                throw new IOException("Anthropic API error "
                                    + response.statusCode()
                                    + ": "
                                    + errorBody
                );
            }

            // Read Server-Sent Events one line at a time
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(responseBody, StandardCharsets.UTF_8))) {
                String eventName = "";
                String line;

                while ((line = reader.readLine()) != null) {

                    // Stop processing when task is cancelled
                    if (Thread.currentThread().isInterrupted()) {
                        throw new InterruptedException("Anthropic streaming request was cancelled.");
                    }
                    //A blank line marks the end of one Server-Sent Event
                    if (line.isBlank()) {
                        eventName = "";
                        continue;
                    }
                    // Store the event name from lines
                    if (line.startsWith("event:")) {
                        eventName = line.substring("event:".length()).trim();
                        continue;
                    }
                    // Ignore lines that do not contain event data
                    if (!line.startsWith("data:")) {
                        continue;
                    }
                    // Removes "data" prefix before parsing JSON event
                    String data = line.substring("data:".length()).trim();
                    if (data.isEmpty() || "[DONE]".equals(data)) {
                        continue;
                    }

                    JsonNode event = mapper.readTree(data);

                    /*
                     Prefer the type included in JSON.
                     Fallback when needed.
                     */
                    String eventType = event.path("type").asText(eventName);

                    // A content_block_delta may contain generated text
                    if ("content_block_delta".equals(eventType)) {
                        JsonNode delta = event.path("delta");

                        if ("text_delta".equals(delta.path("type").asText())) {
                            String text = delta.path("text").asText("");
                            if (!text.isEmpty()) {
                                onTextChunk.accept(text);
                            }
                        }

                        // Anthropic may send error event after streaming connection has started
                    } else if ("error".equals(eventType)) {
                        JsonNode error = event.path("error");
                        String errorType = error.path("type")
                                .asText("stream_error");
                        String message = error.path("message")
                                .asText("Unknown Anthropic streaming error.");

                        throw new IOException("Anthropic " + errorType + ": " + message
                        );

                        // message_stop indicates Anthropic has finished generating its response
                    } else if ("message_stop".equals(eventType)) {
                        return;
                    }
                }
            }
        }
    }

    // Creates the JSON request body required by Anthropic Messages API
    private ObjectNode buildRequestBody(String systemPrompt, String userPrompt, boolean streaming) {

        ObjectNode body = mapper.createObjectNode();
        body.put("model", model);
        body.put("max_tokens", maxTokens);
        body.put("stream", streaming);

        // Include system prompt only when usable system instructions were provided
        if (systemPrompt != null && !systemPrompt.isBlank()) {
            body.put("system", systemPrompt);
        }

        // Create the messages array expected by Anthropic API
        ArrayNode messages = mapper.createArrayNode();
        ObjectNode userMessage = mapper.createObjectNode();
        userMessage.put("role", "user");
        userMessage.put("content", userPrompt);
        messages.add(userMessage);
        body.set("messages", messages);

        return body;
    }

    // Converts JSON request body into an HTTP request containing the required Anthropic headers
    private HttpRequest buildRequest(ObjectNode body) throws IOException {

        return HttpRequest.newBuilder()
                .uri(URI.create(ENDPOINT))
                .timeout(Duration.ofSeconds(120))       // Allow up to 120 seconds before Anthropic times out
                .header("content-type", "application/json")
                .header("x-api-key", apiKey)
                .header("anthropic-version", ANTHROPIC_VERSION)
                .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
                .build();
    }

    @Override
    public String model() {
        return model;
    }
}