package com.campus.client.llm;

import java.util.Objects;
import java.util.function.Consumer;

/*
Common contract for the Large Language Model clients. Implementations talk to one provider
(Anthropic, OpenAI, Google Gemini, &hellip;) over HTTP and return generated text.

The whole rest of the app depends only on this interface, so swapping providers is just a
constructor change in {@link com.campus.client.App}.
*/
public interface LlmClient {

    /**
     * Generates a response for one user prompt with an optional system prompt.
     *
     * @param systemPrompt framing/instructions for the model (may be {@code null} or blank)
     * @param userPrompt   the user message; in this assignment, the retrieved RAG context plus
     *                     the student's question
     * @return the model's generated text
     */

    String complete(String systemPrompt, String userPrompt) throws Exception;

    /**
     * Providers without genuine streaming remain compatible by returning
     * their complete response as one chunk. AnthropicClient overrides this.
     */

    default void streamComplete(String systemPrompt, String userPrompt, Consumer<String> onTextChunk) throws Exception {
        Objects.requireNonNull(onTextChunk, "Text chunk callback cannot be null.");

        String response = complete(systemPrompt, userPrompt);
        if (response != null && !response.isEmpty()) {
            onTextChunk.accept(response);
        }
    }

    /** @return the model identifier this client is using (for display in the UI / logs). */
    String model();
}
