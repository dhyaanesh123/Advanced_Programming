package com.campus.client.controllers;

import com.campus.client.mcp.CampusMcpClient;
import com.campus.client.rag.RagResult;
import com.campus.client.rag.RagService;
import com.campus.client.services.AiTaskService;
import com.campus.client.services.AuthService;
import com.campus.client.services.ChatService;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.util.Duration;

import java.util.ArrayDeque;
import java.util.Locale;
import java.util.Queue;

public class StudentAiAssistant {

    private CampusMcpClient mcpClient;
    private AuthService authService;
    private RagService ragService;
    private AiTaskService aiTaskService;
    private ChatService chatService;
    private static final String THINKING_BLOCK = "Assistant:\nThinking...\n\n";
    private static final Duration TYPING_INTERVAL = Duration.millis(8);

    @FXML
    private TextArea conversationArea;

    @FXML
    private TextArea inputArea;

    @FXML
    private Button sendButton;

    private final Queue<Character> typingQueue = new ArrayDeque<>();

    private final StringBuilder streamedAnswer = new StringBuilder();

    private Timeline typingTimeline;
    private boolean streamStarted;
    private boolean streamCompleted;
    private RagResult completedResult;
    private long requestSequence;

    @FXML
    private void initialize() {
        typingTimeline = new Timeline(new KeyFrame(TYPING_INTERVAL, event -> typeNextCharacter()));
        typingTimeline.setCycleCount(Animation.INDEFINITE);
    }

    public void setMcpClient(CampusMcpClient mcpClient) {
        this.mcpClient = mcpClient;
    }

    public void setRagService(RagService ragService) {
        this.ragService = ragService;
    }

    public void setAuthService(AuthService authService) {
        this.authService = authService;
    }

    public void setAiTaskService(AiTaskService aiTaskService) {
        this.aiTaskService = aiTaskService;
    }

    public void setChatService(ChatService chatService) {
        this.chatService = chatService;

        if (conversationArea != null && chatService != null) {
            conversationArea.setText(chatService.getConversation());
            conversationArea.positionCaret(conversationArea.getLength());
        }
    }

    @FXML
    private void handleSend() {
        if (ragService == null) {
            appendTemporaryError("The AI Assistant is unavailable because RagService was not initialised.");
            return;
        }
        if (aiTaskService == null) {
            appendTemporaryError("The AI task service was not initialised.");
            return;
        }
        if (chatService == null) {
            appendTemporaryError("The chat service was not initialised.");
            return;
        }
        if (aiTaskService.isRunning() || streamStarted) {
            appendTemporaryError("Please wait for the current response.");
            return;
        }

        String question = inputArea.getText().trim();
        if (question.isEmpty()) {
            return;
        }

        String conversationHistory = chatService.getRecentConversation(8);

        String userMessage = "You:\n" + question + "\n\n";

        conversationArea.appendText(userMessage);
        chatService.addMessage(userMessage);
        inputArea.clear();

        resetStreamingState();
        setInputDisabled(true);

        conversationArea.appendText(THINKING_BLOCK);
        conversationArea.positionCaret(conversationArea.getLength());

        String topic = identifyTopic(question);
        long requestId = ++requestSequence;

        try {
            aiTaskService.startStreamingTask(
                    question,
                    topic,
                    conversationHistory,
                    ragService,
                    chunk -> handleStreamChunk(requestId, chunk),
                    result -> handleStreamSucceeded(requestId, result),
                    error -> handleStreamFailure(requestId, error)
            );
        } catch (Exception exception) {
            handleStreamFailure(requestId, exception);
        }
    }


    // Called from the background streaming thread
    private void handleStreamChunk(long requestId, String chunk) {
        if (chunk == null || chunk.isEmpty()) {
            return;
        }
        Platform.runLater(() -> {
            if (requestId != requestSequence) {
                return;
            }
            if (!streamStarted) {
                removeThinkingBlock();
                conversationArea.appendText("Assistant:\n");
                streamStarted = true;
            }
            streamedAnswer.append(chunk);
            enqueueCharacters(chunk);
        });
    }

    private void handleStreamSucceeded(
            long requestId,
            RagResult result
    ) {
        if (requestId != requestSequence) {
            return;
        }
        completedResult = result;
        streamCompleted = true;

        if (!streamStarted) {
            removeThinkingBlock();
            conversationArea.appendText("Assistant:\n");
            streamStarted = true;
        }

        String completeAnswer = result == null
                ? ""
                : result.answer();

        String received = streamedAnswer.toString();

        if (!completeAnswer.isBlank()
                && completeAnswer.startsWith(received)
                && completeAnswer.length() > received.length()) {

            String missingSuffix = completeAnswer.substring(
                    received.length()
            );
            streamedAnswer.append(missingSuffix);
            enqueueCharacters(missingSuffix);
        }
        finishStreamingIfReady();
    }

    private void handleStreamFailure(long requestId, Throwable error) {
        if (requestId != requestSequence) {
            return;
        }

        typingTimeline.stop();
        typingQueue.clear();

        String message = error == null || error.getMessage() == null || error.getMessage().isBlank()
                ? "Unknown AI error."
                : error.getMessage();

        String errorMessage = "Assistant:\nSorry, I couldn't complete that response. " + message + "\n\n";

        if (!streamStarted) {
            replaceThinkingBlock(errorMessage);
        } else {
            conversationArea.appendText("\n\nSorry, the response was interrupted. " + message + "\n\n");
        }

        chatService.addMessage(errorMessage);
        setInputDisabled(false);
        resetStreamingState();

        if (error != null) {
            error.printStackTrace();
        }
    }

    private void enqueueCharacters(String text) {
        for (int index = 0; index < text.length(); index++) {
            typingQueue.offer(text.charAt(index));
        }

        if (typingTimeline.getStatus() != Animation.Status.RUNNING) {
            typingTimeline.play();
        }
    }

    private void typeNextCharacter() {
        Character nextCharacter = typingQueue.poll();

        if (nextCharacter != null) {
            conversationArea.appendText(String.valueOf(nextCharacter));
            conversationArea.positionCaret(conversationArea.getLength());
            return;
        }

        typingTimeline.stop();
        finishStreamingIfReady();
    }

    private void finishStreamingIfReady() {
        if (!streamCompleted || !typingQueue.isEmpty()) {
            return;
        }

        typingTimeline.stop();
        conversationArea.appendText("\n\n");

        String finalAnswer = completedResult == null
                ? streamedAnswer.toString().trim()
                : completedResult.answer().trim();

        if (!finalAnswer.isBlank()) {
            chatService.addMessage("Assistant:\n" + finalAnswer + "\n\n"
            );
        }
        conversationArea.positionCaret(conversationArea.getLength());
        setInputDisabled(false);
        resetStreamingState();
        inputArea.requestFocus();
    }

    private void resetStreamingState() {
        if (typingTimeline != null) {
            typingTimeline.stop();
        }

        typingQueue.clear();
        streamedAnswer.setLength(0);
        streamStarted = false;
        streamCompleted = false;
        completedResult = null;
    }

    private void setInputDisabled(boolean disabled) {
        if (inputArea != null) {
            inputArea.setDisable(disabled);
        }

        if (sendButton != null) {
            sendButton.setDisable(disabled);
        }
    }

    private void removeThinkingBlock() {
        String current = conversationArea.getText();
        int index = current.lastIndexOf(THINKING_BLOCK);

        if (index < 0) {
            return;
        }

        conversationArea.setText(current.substring(0, index)
                + current.substring(index + THINKING_BLOCK.length())
        );
    }

    private void replaceThinkingBlock(String replacement) {
        String current = conversationArea.getText();
        int index = current.lastIndexOf(THINKING_BLOCK);

        if (index < 0) {
            conversationArea.appendText(replacement);
            return;
        }

        conversationArea.setText(current.substring(0, index)
                        + replacement
                        + current.substring(index + THINKING_BLOCK.length())
        );

        conversationArea.positionCaret(conversationArea.getLength());
    }

    private void appendTemporaryError(String message) {
        conversationArea.appendText("System:\n" + message + "\n\n");
        conversationArea.positionCaret(conversationArea.getLength());
    }

    private String identifyTopic(String question) {
        String lower = question.toLowerCase(Locale.ROOT);

        if (lower.contains("facility")
                || lower.contains("facilities")
                || lower.contains("room")
                || lower.contains("lab")
                || lower.contains("pod")
                || lower.contains("court")
                || lower.contains("sport")) {
            return "campus facilities";
        }
        if (lower.contains("book")
                || lower.contains("booking")
                || lower.contains("cancel")
                || lower.contains("duration")
                || lower.contains("limit")
                || lower.contains("availability")) {
            return "resource booking policies";
        }
        if (lower.contains("handbook")
                || lower.contains("rule")
                || lower.contains("policy")) {
            return "student handbook and campus policies";
        }
        return "general campus services";
    }

    public void clearConversation() {
        ++requestSequence;

        if (aiTaskService != null) {
            aiTaskService.cancelCurrentTask();
        }
        resetStreamingState();
        setInputDisabled(false);

        if (conversationArea != null) {
            conversationArea.clear();
        }
        if (inputArea != null) {
            inputArea.clear();
        }
        if (chatService != null) {
            chatService.clearConversation();
        }
    }
}