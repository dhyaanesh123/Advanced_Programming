package com.campus.client.controllers;
import com.campus.client.mcp.CampusMcpClient;
import com.campus.client.services.AuthService;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class StudentFacilityPage {

    @FXML
    private TextArea facilitiesArea;

    private CampusMcpClient mcpClient;
    private AuthService authService;

    public void setAuthService(AuthService authService) {
        this.authService = authService;
    }

    public void setMcpClient(CampusMcpClient mcpClient) {
        this.mcpClient = mcpClient;
        loadFacilities();
    }

    private void loadFacilities() {
        try {
            String result = mcpClient.readResource("campus://facilities");
            facilitiesArea.setText(result);

        } catch (Exception e) {
            facilitiesArea.setText("Unable to load facilities.\n\n" + e.getMessage());
        }
    }

}