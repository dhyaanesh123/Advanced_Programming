package com.campus.client.models;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED,
    COMPLETED
}
