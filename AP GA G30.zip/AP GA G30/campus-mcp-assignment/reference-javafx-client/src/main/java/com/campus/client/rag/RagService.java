package com.campus.client.rag;

import com.campus.client.llm.LlmClient;
import com.campus.client.mcp.CampusMcpClient;

import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;

public final class RagService {

    // Returned when no relevant information can be retrieved
    private static final String NO_CONTEXT_RESPONSE =
            "I couldn't find enough information in the campus "
                    + "knowledge base to answer that confidently. "
                    + "You may need to check with Campus Services.";

    private final CampusMcpClient mcp;
    private final LlmClient llm;

    public RagService(CampusMcpClient mcp, LlmClient llm) {
        this.mcp = Objects.requireNonNull(mcp, "CampusMcpClient cannot be null.");      // Stop MCP service when dependency is missing
        this.llm = Objects.requireNonNull(llm, "LlmClient cannot be null.");            // Stop LLM service when dependency is missing
    }

    /*
    Generates an AI response using text streaming.
    Retrieval occurs before forwarding Anthropic text.
     */
    public RagResult streamAsk(
            String question,
            String topic,
            String conversationHistory,
            Consumer<String> onTextChunk
    ) throws Exception {

        // Callback is required because it receives each part of the streamed AI response
        Objects.requireNonNull(onTextChunk, "Text chunk callback cannot be null.");

        PromptData promptData = preparePrompt(question, topic, conversationHistory);

        // Send fallback response through the same callback
        if (promptData.context().isBlank()) {onTextChunk.accept(NO_CONTEXT_RESPONSE);
            return new RagResult(NO_CONTEXT_RESPONSE, "");
        }

        // Stores all received text chunks, returns the complete answer after streaming finishes
        StringBuilder answer = new StringBuilder();

        llm.streamComplete(promptData.systemPrompt(), promptData.userPrompt(),
                chunk -> {

                    // Ignore empty chunks
                    if (chunk == null || chunk.isEmpty()) {
                        return;
                    }
                    answer.append(chunk);
                    onTextChunk.accept(chunk);      // Passes the current text chunk
                }
        );

        if (answer.toString().isBlank()) {
            throw new IllegalStateException("The LLM returned an empty response.");
        }

        return new RagResult(answer.toString().trim(), promptData.context()
        );
    }

    // Retrieves relevant campus information & prepares the prompts to be sent to the LLM
    private PromptData preparePrompt(
            String question,
            String topic,
            String conversationHistory
    ) throws Exception {

        if (question == null || question.isBlank()) {
            throw new IllegalArgumentException("Question cannot be empty.");
        }

        String cleanedQuestion = question.trim();

        String history = conversationHistory == null
                ? ""                            // Empty string is used when there is no history
                : conversationHistory.trim();

        // General topic is used when topic is not specified
        String effectiveTopic = topic == null || topic.isBlank()
                ? "general campus services"
                : topic.trim();

        // Include recent conversation history in retrieval query so follow-up questions can be understood by the LLM
        String retrievalQuery = history.isBlank()
                ? cleanedQuestion
                : history
                  + "\nCurrent question: "
                  + cleanedQuestion;

        // Search knowledge base for five of the most relevant information
        String searchContext = cleanContext(
                mcp.callTool("search_campus_info",
                        Map.of("query", retrievalQuery, "topK", 5)
                )
        );

        // Retrieve the complete facilities or handbook resource when questions contain matching keywords
        String directContext = cleanContext(getDirectContext(cleanedQuestion + "\n" + history));

        // Combine semantic search results with any directly retrieved resource content
        String context = combineContext(searchContext, directContext);

        // Retrieve campus assistant prompt by the MCP server
        String serverSystemPrompt = mcp.getPrompt("campus_assistant", Map.of("topic", effectiveTopic));

        // Additional instructions
        String conversationalStyle = """
                Speak like a helpful campus staff member having a normal
                one-to-one conversation with a student.

                Response style requirements:
                - Answer naturally in plain text.
                - Give the useful answer directly without repeatedly saying
                  "Based on the available information".
                - Prefer one to three short paragraphs.
                - Use a short list only when it genuinely improves clarity.
                - Do not use Markdown headings, Markdown tables, decorative
                  separators, source filenames, raw citation markers, or
                  bracketed file references.
                - Do not expose or describe the retrieved context.
                - Do not invent campus facilities, policies, opening hours,
                  availability, or booking rules.
                - If the information is missing, say so conversationally and
                  suggest the most relevant campus office.
                """;

        // Combines MCP system prompt with the application's instructions
        String combinedSystemPrompt = cleanContext(serverSystemPrompt)
                + "\n\n"
                + conversationalStyle;


        // Build final user prompt
        String userPrompt = """
                Recent conversation:
                %s

                Campus information:
                %s

                Student's current question:
                %s

                Continue the conversation naturally and answer only what is
                relevant to the student's question.
                """.formatted(
                history.isBlank()
                        ? "(No previous conversation.)"
                        : history,
                context.isBlank()
                        ? "(No relevant campus information was retrieved.)"
                        : context,
                cleanedQuestion
        );

        return new PromptData(context, combinedSystemPrompt.trim(), userPrompt.trim());
    }

    // Retrieves an entire MCP resource when student's questions contain matching keywords
    private String getDirectContext(String questionAndHistory) {
        String lower = questionAndHistory.toLowerCase(Locale.ROOT);

        try {
            // Rooms, facilities, opening hours
            // Uses campus://facilities
            if (lower.contains("facility")
                    || lower.contains("facilities")
                    || lower.contains("room")
                    || lower.contains("lab")
                    || lower.contains("pod")
                    || lower.contains("court")
                    || lower.contains("sport")
                    || lower.contains("opening hour")
                    || lower.contains("close")
                    || lower.contains("open")) {

                return mcp.readResource("campus://facilities");
            }

            // Booking rules, policies
            // Uses campus://handbook
            if (lower.contains("policy")
                    || lower.contains("rule")
                    || lower.contains("cancel")
                    || lower.contains("booking limit")
                    || lower.contains("duration")
                    || lower.contains("advance booking")
                    || lower.contains("check-in")) {

                return mcp.readResource("campus://handbook");
            }

        } catch (Exception exception) {
            System.out.println("Unable to retrieve direct context: " + exception.getMessage());
        }

        return "";
    }

    // Converts null and MCP error messages into an empty String
    private String cleanContext(String value) {
        if (value == null || value.isBlank()) {
            return "";
        }

        String cleaned = value.trim();

        //MCP tool error is not included int the information sent to LLM
        if (cleaned.toUpperCase(Locale.ROOT).startsWith("ERROR:")) {
            return "";
        }

        return cleaned;
    }

    // Combines two retrieved context values while avoiding blank lines
    private String combineContext(String first, String second) {
        if (first.isBlank()) {
            return second;
        }

        if (second.isBlank()) {
            return first;
        }

        return first + "\n\n" + second;
    }

    /*
     Stores the values prepared for LLM request.
     private record is suitable because these values are imutable and are only used inside RagService.
     */
    private record PromptData(String context, String systemPrompt, String userPrompt) {}

}