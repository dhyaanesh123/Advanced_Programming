package com.campus.client.controllers;
import com.campus.client.mcp.CampusMcpClient;
import com.campus.client.services.AuthService;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class StudentHandbookPage {

    @FXML
    private TextArea handbookArea;

    private CampusMcpClient mcpClient;
    private AuthService authService;

    public void setAuthService(AuthService authService) {
        this.authService = authService;
    }

    public void setMcpClient(CampusMcpClient mcpClient) {
        this.mcpClient = mcpClient;
        loadHandbook();
    }

    private void loadHandbook() {
        try {
            String result = mcpClient.readResource("campus://handbook");
            handbookArea.setText(result);

        } catch (Exception e) {
            handbookArea.setText("Unable to load handbook.\n\n" + e.getMessage());
        }
    }

}